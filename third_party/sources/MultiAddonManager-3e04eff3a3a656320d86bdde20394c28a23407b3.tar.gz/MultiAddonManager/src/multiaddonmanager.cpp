/**
 * =============================================================================
 * MultiAddonManager
 * Copyright (C) 2024-2026 xen
 * =============================================================================
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, version 3.0, as published by the
 * Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more
 * details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "multiaddonmanager.h"
#include "networkbasetypes.pb.h"
#include "module.h"
#include "convar.h"
#include "filesystem/ifilesystem.h"
#include <string>
#include <sstream>
#include <fstream>

#include "tier0/memdbgon.h"

CConVar<bool> mm_addon_mount_download("mm_addon_mount_download", FCVAR_NONE, "Whether to download an addon upon mounting even if it's installed", false);
CConVar<bool> mm_block_disconnect_messages("mm_block_disconnect_messages", FCVAR_NONE, "Whether to block \"loop shutdown\" disconnect messages", false);
CConVar<bool> mm_cache_clients_with_addons("mm_cache_clients_with_addons", FCVAR_NONE, "Whether to cache clients addon download list, this will prevent reconnects on mapchange/rejoin", false);
CConVar<float> mm_cache_clients_duration("mm_cache_clients_duration", FCVAR_NONE, "How long to cache clients' downloaded addons list in seconds, pass 0 for forever.", 0.0f);
CConVar<float> mm_addon_connection_timeout("mm_addon_connection_timeout", FCVAR_NONE, "How long until clients are timed out while downloading the first required addon (usually the current map), 0 disables", 30.f);
CConVar<float> mm_extra_addons_timeout("mm_extra_addons_timeout", FCVAR_NONE, "How long until clients are timed out in between connects for extra addons in seconds, requires mm_extra_addons to be used", 10.f);

CConVar<bool> mm_addon_debug("mm_addon_debug", FCVAR_NONE, "Whether to print some extra debug information", false);

void Message(const char *msg, ...)
{
	va_list args;
	va_start(args, msg);

	char buf[1024] = {};
	V_vsnprintf(buf, sizeof(buf) - 1, msg, args);

	LoggingSystem_Log(2, LS_MESSAGE, Color(0, 255, 200, 255), "[MultiAddonManager] %s", buf);

	va_end(args);
}

void Panic(const char *msg, ...)
{
	va_list args;
	va_start(args, msg);

	char buf[1024] = {};
	V_vsnprintf(buf, sizeof(buf) - 1, msg, args);

	Warning("[MultiAddonManager] %s", buf);

	va_end(args);
}

void StringToVector(const char *pszString, std::vector<AddonId> &vector)
{
	vector.clear();

	if (!pszString)
		return;

	std::string token;
	std::istringstream stream(pszString);

	while (std::getline(stream, token, ','))
	{
		if (!token.empty())
		{
			for (auto it = token.begin(); it < token.end(); it++)
				if (std::isspace(*it)) token.erase(it);

			vector.emplace_back(token);
		}
	}
}

std::string VectorToString(const std::vector<AddonId> &vector)
{
	std::string result;

	for (const auto &addon : vector)
	{
		if (!result.empty())
			result += ',';

		result += addon.c_str();
	}

	return result;
}

ISteamUGC *GetSteamUGC()
{
	if (g_pEngineServer->IsDedicatedServer())
		return SteamGameServerUGC();
	else
		return SteamUGC();
}

// Will return null between map end & new map startup, null check if necessary!
CNetworkGameServerBase* GetNetworkGameServer()
{
	return g_pNetworkServerService->GetIGameServer();
}

// Will return null between map end & new map startup, null check if necessary!
CGlobalVars* GetGlobals()
{
	return g_pEngineServer->GetServerGlobals();
}

// Signatures

// "Discarding pending request '%s, %u'\n"
// "Sending S2C_CONNECTION to %s [addons:'%s']\n"
// First call without args in func with "Saving existing workshop save file from %s\n"
#ifdef PLATFORM_WINDOWS
constexpr const char *g_HostStateRequest_Sig = "48 89 74 24 ? 57 48 83 EC ? 33 F6 48 8B FA 48 39 35";
constexpr const char *g_ReplyConnection_Sig = "48 8B C4 55 41 55 41 56";
constexpr const char *g_ScriptGetAddon_Sig = "40 56 48 83 EC ? 48 8B 0D ? ? ? ? 48 8D 54 24";
#else
constexpr const char *g_HostStateRequest_Sig = "55 48 89 E5 41 56 41 55 41 54 49 89 F4 53 48 83 7F";
constexpr const char *g_ReplyConnection_Sig = "55 B9 ? ? ? ? 41 B8 ? ? ? ? 48 89 E5";
constexpr const char *g_ScriptGetAddon_Sig = "55 48 89 E5 41 55 41 54 48 8D 75 ? 53 48 83 EC ? 48 8D 05 ? ? ? ? 48 C7 45 ? ? ? ? ? 48 C7 45 ? ? ? ? ? 48 8B 38 48 8B 07 FF 90 ? ? ? ? 8B 55";
#endif

/* 
The general workflow is defined as follows:
0. The server defines a list of server side addons and global client side addons to mount.
1. Client connects and request for the list of addons through ReplyConnection. MAM get the full list of addons to load.
2. If there is at least one addon to load, client will be prompted to download the first addon.
3. Once done, client reconnects and ClientConnect fires. If connected within the timeout interval, MAM marks this first addon as downloaded, 
	then check if there are other addons to download. If there is at least one, it will send a signon message to the client through SendNetMessage.
4. Client will be prompted to download the next addon. Client reconnects and ClientConnect fires again. 
	MAM marks the previous downloading addon (the one sent in the previous signon message) as done, and keep sending signon messages until all addons are downloaded.
5. Once all addons are downloaded, MAM stops sending custom signon messages.
Note: 
The list of addons to download does not have to be in order, but the addon list that the client uses to load is. This order is somewhat arbitrarily defined as follows: 
	- Original server workshop map (if any)
	- Server side *mounted* addons (m_MountedAddons)
	- Client side global addons (m_GlobalClientAddons)
	- Client side client-specific addons (addonsToLoad).
While plugins using the interface can add/remove addons at any time between these steps, it should be fine since the list of addon to load is newly checked every time the client connects.
*/

enum ClientConnectedState_t
{
	CLIENTCONN_NONE,
	CLIENTCONN_CONNECTING,
	CLIENTCONN_JOINED
};

struct ClientAddonInfo_t
{
	double lastActiveTime {};
	std::vector<AddonId> addonsToLoad;
	std::vector<AddonId> downloadedAddons;
	AddonId currentPendingAddon;
	ClientConnectedState_t connectedState = CLIENTCONN_NONE;
	double connectionStartTime {};
};

std::unordered_map<uint64, ClientAddonInfo_t> g_ClientAddons;

CConVar<CUtlString> mm_extra_addons("mm_extra_addons", FCVAR_NONE, "The workshop IDs of extra addons separated by commas, addons will be downloaded (if not present) and mounted", CUtlString(""),
	[](CConVar<CUtlString> *cvar, CSplitScreenSlot slot, const CUtlString *new_val, const CUtlString *old_val)
	{
		StringToVector(new_val->Get(), g_MultiAddonManager.m_ExtraAddons);

		g_MultiAddonManager.RefreshAddons();
	});


CConVar<CUtlString> mm_client_extra_addons("mm_client_extra_addons", FCVAR_NONE, "The workshop IDs of extra client addons that will be applied to all clients, separated by commas", CUtlString(""),
	[](CConVar<CUtlString> *cvar, CSplitScreenSlot slot, const CUtlString *new_val, const CUtlString *old_val)
	{
		StringToVector(new_val->Get(), g_MultiAddonManager.m_GlobalClientAddons);
	});

IGameEventSystem *g_pGameEventSystem = nullptr;

IGameEventManager2 *g_pGameEventManagerVTable = nullptr;
CServerSideClientBase *g_pServerSideClientVTable = nullptr;
CServerSideClientBase *g_pHLTVClientVTable = nullptr;

MultiAddonManager g_MultiAddonManager;
PLUGIN_EXPOSE(MultiAddonManager, g_MultiAddonManager);

MultiAddonManager::MultiAddonManager() :
	m_hookGameFrame(&IServerGameDLL::GameFrame, this, nullptr, &MultiAddonManager::Hook_GameFrame_Post),
	m_hookStartupServer(&INetworkServerService::StartupServer, this, nullptr, &MultiAddonManager::Hook_StartupServer_Post),
	m_hookClientConnect(&IServerGameClients::ClientConnect, this, &MultiAddonManager::Hook_ClientConnect, nullptr),
	m_hookCanHLTVClientConnect(&IServerGameClients::CanHLTVClientConnect, this, &MultiAddonManager::Hook_CanHLTVClientConnect, nullptr),
	m_hookClientDisconnect(&IServerGameClients::ClientDisconnect, this, nullptr, &MultiAddonManager::Hook_ClientDisconnect_Post),
	m_hookClientActive(&IServerGameClients::ClientActive, this, nullptr, &MultiAddonManager::Hook_ClientActive_Post),
	m_hookFireEvent(&IGameEventManager2::FireEvent, this, &MultiAddonManager::Hook_FireEvent, nullptr),
	m_hookSendNetMessage_ServerSideClient(&CServerSideClientBase::SendNetMessage, this, &MultiAddonManager::Hook_SendNetMessage, nullptr),
	m_hookSendNetMessage_HLTVClient(&CServerSideClientBase::SendNetMessage, this, &MultiAddonManager::Hook_SendNetMessage, nullptr),
	m_hookSwitchToLoop(&IEngineServiceMgr::SwitchToLoop, this, &MultiAddonManager::Hook_SwitchToLoop, nullptr),
	m_hookSetPendingHostStateRequest(this, &MultiAddonManager::Hook_SetPendingHostStateRequest, nullptr),
	m_hookReplyConnection(this, &MultiAddonManager::Hook_ReplyConnection, nullptr),
	m_hookScriptGetAddon(this, &MultiAddonManager::Hook_ScriptGetAddon, nullptr)
{
}

bool MultiAddonManager::Load(PluginId id, ISmmAPI *ismm, char *error, size_t maxlen, bool late)
{
	PLUGIN_SAVEVARS();

	GET_V_IFACE_ANY(GetEngineFactory, g_pEngineServer, IVEngineServer, SOURCE2ENGINETOSERVER_INTERFACE_VERSION);
	GET_V_IFACE_ANY(GetEngineFactory, g_pCVar, ICvar, CVAR_INTERFACE_VERSION);
	GET_V_IFACE_ANY(GetServerFactory, g_pSource2GameClients, IServerGameClients, INTERFACEVERSION_SERVERGAMECLIENTS);
	GET_V_IFACE_ANY(GetServerFactory, g_pSource2Server, ISource2Server, SOURCE2SERVER_INTERFACE_VERSION);
	GET_V_IFACE_ANY(GetEngineFactory, g_pNetworkServerService, INetworkServerService, NETWORKSERVERSERVICE_INTERFACE_VERSION);
	GET_V_IFACE_ANY(GetEngineFactory, g_pNetworkMessages, INetworkMessages, NETWORKMESSAGES_INTERFACE_VERSION);
	GET_V_IFACE_ANY(GetEngineFactory, g_pGameEventSystem, IGameEventSystem, GAMEEVENTSYSTEM_INTERFACE_VERSION);
	GET_V_IFACE_ANY(GetEngineFactory, g_pEngineServiceMgr, IEngineServiceMgr, ENGINESERVICEMGR_INTERFACE_VERSION);
	GET_V_IFACE_ANY(GetFileSystemFactory, g_pFullFileSystem, IFileSystem, FILESYSTEM_INTERFACE_VERSION);
	GET_V_IFACE_ANY(GetEngineFactory, g_pHostStateMgr, IHostStateMgr, HOSTSTATEMGR_INTERFACE_VERSION);

	// Required to get the IMetamodListener events
	g_SMAPI->AddListener( this, this );

	CModule engineModule(ROOTBIN, "engine2");
	CModule serverModule(GAMEBIN, "server");

	bool g_bRequiredInitLoaded = true;

	auto pfnSetPendingHostStateRequest = engineModule.LookupSignature(g_HostStateRequest_Sig);

	if (!pfnSetPendingHostStateRequest)
	{
		Panic("Failed to lookup the signature for HostStateRequest\n");
		g_bRequiredInitLoaded = false;
	}

	m_hookSetPendingHostStateRequest.Configure(pfnSetPendingHostStateRequest);

	auto pfnReplyConnection = engineModule.LookupSignature(g_ReplyConnection_Sig);

	if (!pfnReplyConnection)
	{
		Panic("Failed to lookup the signature for ReplyConnection\n");
		g_bRequiredInitLoaded = false;
	}

	m_hookReplyConnection.Configure(pfnReplyConnection);
	
	auto pfnScriptGetAddon = serverModule.LookupSignature(g_ScriptGetAddon_Sig);

	if (!pfnScriptGetAddon)
	{
		Panic("Failed to lookup the signature for ScriptGetAddon\n");
		g_bRequiredInitLoaded = false;
	}

	m_hookScriptGetAddon.Configure(pfnScriptGetAddon);

	if (!(g_pGameEventManagerVTable = (IGameEventManager2 *)serverModule.FindVirtualTable("CGameEventManager")))
	{
		Panic("Failed to lookup the vtable for CGameEventManager\n");
		g_bRequiredInitLoaded = false;
	}

	if (!(g_pServerSideClientVTable = (CServerSideClientBase *)engineModule.FindVirtualTable("CServerSideClient")))
	{
		Panic("Failed to lookup the vtable for CServerSideClient\n");
		g_bRequiredInitLoaded = false;
	}

	if (!(g_pHLTVClientVTable = (CServerSideClientBase *)engineModule.FindVirtualTable("CHLTVClient")))
	{
		Panic("Failed to lookup the vtable for CHLTVClient\n");
		g_bRequiredInitLoaded = false;
	}

	if (!g_bRequiredInitLoaded)
	{
		V_snprintf(error, maxlen, "One or more address lookups failed, please refer to startup logs for more information");
		return false;
	}

	m_hookClientConnect.Add(g_pSource2GameClients);
	m_hookCanHLTVClientConnect.Add(g_pSource2GameClients);
	m_hookClientDisconnect.Add(g_pSource2GameClients);
	m_hookClientActive.Add(g_pSource2GameClients);
	m_hookGameFrame.Add(g_pSource2Server);
	m_hookStartupServer.Add(g_pNetworkServerService);
	m_hookSwitchToLoop.Add(g_pEngineServiceMgr);
	m_hookFireEvent.AddGlobal((IGameEventManager2*)&g_pGameEventManagerVTable);
	m_hookSendNetMessage_ServerSideClient.AddGlobal((CServerSideClientBase*)&g_pServerSideClientVTable);
	m_hookSendNetMessage_HLTVClient.AddGlobal((CServerSideClientBase*)&g_pHLTVClientVTable);

	if (g_pEngineServer->IsDedicatedServer())
	{
		m_CallbackDownloadItemResult.Register(this, &MultiAddonManager::OnAddonDownloaded);
		m_CallbackSteamServersConnected.Register(this, &MultiAddonManager::OnSteamServersConnected);
	}

	META_CONVAR_REGISTER(FCVAR_RELEASE);

	ParseCfg();

	Message("Plugin loaded successfully!\n");

	return true;
}

bool MultiAddonManager::Unload(char *error, size_t maxlen)
{
	ClearAddons();

	m_CallbackDownloadItemResult.Unregister();
	m_CallbackSteamServersConnected.Unregister();

	m_hookClientConnect.Remove(g_pSource2GameClients);
	m_hookCanHLTVClientConnect.Remove(g_pSource2GameClients);
	m_hookClientDisconnect.Remove(g_pSource2GameClients);
	m_hookClientActive.Remove(g_pSource2GameClients);
	m_hookGameFrame.Remove(g_pSource2Server);
	m_hookStartupServer.Remove(g_pNetworkServerService);
	m_hookFireEvent.RemoveGlobal((IGameEventManager2*)&g_pGameEventManagerVTable);
	m_hookSendNetMessage_ServerSideClient.RemoveGlobal((CServerSideClientBase *)&g_pServerSideClientVTable);
	m_hookSendNetMessage_HLTVClient.RemoveGlobal((CServerSideClientBase *)&g_pHLTVClientVTable);
	
	return true;
}

void *MultiAddonManager::OnMetamodQuery(const char *iface, int *ret)
{
	if (V_strcmp(iface, MULTIADDONMANAGER_INTERFACE))
	{
		if (ret)
			*ret = META_IFACE_FAILED;

		return nullptr;
	}

	if (ret)
		*ret = META_IFACE_OK;

	return static_cast<IMultiAddonManager*>(&g_MultiAddonManager);
}

void MultiAddonManager::ParseCfg()
{
	char szPath[MAX_PATH];
	V_snprintf(szPath, sizeof(szPath), "%s/csgo/cfg/multiaddonmanager/multiaddonmanager.cfg", Plat_GetGameDirectory());
	std::ifstream cfgFile(szPath);

	if (!cfgFile.is_open())
	{
		Panic("Unable to open & execute config at \"%s\"\n");
		return;
	}

	Message("Executing config\n");

	std::string strCommand;

	while (std::getline(cfgFile, strCommand))
	{
		if (!strCommand.empty() && strCommand.back() == '\r')
			strCommand.pop_back();

		CCommand args;
		if (!args.Tokenize(strCommand.c_str()))
			continue;

		const char* pszCommand = args.Arg(0);

		ConVarRefAbstract cvarRef(pszCommand, true);
		if (cvarRef.IsValidRef())
		{
			cvarRef.SetString(args.Arg(1));
			continue;
		}

		ConCommandRef cmdRef(pszCommand, true);
		if (cmdRef.IsValidRef())
		{
			CCommandContext ctx(CT_FIRST_SPLITSCREEN_CLIENT, -1);
			cmdRef.Dispatch(ctx, args);
		}
	}
}

void MultiAddonManager::BuildAddonPath(const char *pszAddon, char *buf, size_t len, bool bLegacy = false)
{
	// The workshop on a dedicated server is stored relative to the working directory for whatever reason
	static CBufferStringGrowable<MAX_PATH> s_sWorkingDir;
	ExecuteOnce(g_pFullFileSystem->GetSearchPath("EXECUTABLE_PATH", GET_SEARCH_PATH_ALL, s_sWorkingDir, 1));

	V_snprintf(buf, len, "%ssteamapps/workshop/content/730/%s/%s%s.vpk", s_sWorkingDir.Get(), pszAddon, pszAddon, bLegacy ? "" : "_dir");
}

bool MultiAddonManager::MountAddon(const char *pszAddon, bool bAddToTail = false)
{
	if (!pszAddon || !*pszAddon)
		return false;

	std::vector<AddonId> serverMountedAddons;
	StringToVector(this->m_CurrentWorkshopMap.c_str(), serverMountedAddons);
	if (Contains(serverMountedAddons, AddonId(pszAddon)))
	{
		Message("%s: Addon %s is already mounted by the server\n", __func__, pszAddon);
		return false;
	}

	const AddonId addon(pszAddon);
	uint32 iAddonState = GetSteamUGC()->GetItemState(addon);

	if (!(iAddonState & k_EItemStateInstalled))
	{
		Message("%s: Addon %s is not installed, queuing a download\n", __func__, pszAddon);
		DownloadAddon(pszAddon, true, true);
		return false;
	}
	else if (mm_addon_mount_download.Get())
	{
		// Queue a download anyway in case the addon got an update and the server desires this, but don't reload the map when done
		DownloadAddon(pszAddon, false, true);
	}

	char pszPath[MAX_PATH];
	BuildAddonPath(pszAddon, pszPath, sizeof(pszPath));

	if (!g_pFullFileSystem->FileExists(pszPath))
	{
		// This might be a legacy addon (before mutli-chunk was introduced), try again without the _dir
		BuildAddonPath(pszAddon, pszPath, sizeof(pszPath), true);

		if (!g_pFullFileSystem->FileExists(pszPath))
		{
			Panic("%s: Addon %s not found at %s\n", __func__, pszAddon, pszPath);
			return false;
		}
	}
	else
	{
		// We still need it without _dir anyway because the filesystem will append suffixes if needed
		BuildAddonPath(pszAddon, pszPath, sizeof(pszPath), true);
	}

	if (Contains(m_MountedAddons, AddonId(pszAddon)))
	{
		Panic("%s: Addon %s is already mounted\n", __func__, pszAddon);
		return false;
	}

	Message("Adding search path: %s\n", pszPath);

	g_pFullFileSystem->AddSearchPath(pszPath, "GAME", bAddToTail ? PATH_ADD_TO_TAIL : PATH_ADD_TO_HEAD, SEARCH_PATH_PRIORITY_VPK);
	m_MountedAddons.push_back(pszAddon);

	return true;
}

bool MultiAddonManager::UnmountAddon(const char *pszAddon)
{
	if (!pszAddon || !*pszAddon)
		return false;

	char path[MAX_PATH];
	BuildAddonPath(pszAddon, path, sizeof(path), true); // We always mount without _dir

	if (!g_pFullFileSystem->RemoveSearchPath(path, "GAME"))
		return false;

	RemoveValue(m_MountedAddons, AddonId(pszAddon));

	Message("Removing search path: %s\n", path);

	return true;
}

void MultiAddonManager::PrintDownloadProgress()
{
	if (m_DownloadQueue.empty())
		return;

	const AddonId &addon = m_DownloadQueue.front();

	uint64 iBytesDownloaded = 0;
	uint64 iTotalBytes = 0;

	if (!GetSteamUGC()->GetItemDownloadInfo(addon, &iBytesDownloaded, &iTotalBytes) || !iTotalBytes)
		return;

	double flMBDownloaded = (double)iBytesDownloaded / 1024 / 1024;
	double flTotalMB = (double)iTotalBytes / 1024 / 1024;

	double flProgress = (double)iBytesDownloaded / (double)iTotalBytes;
	flProgress *= 100.f;

	Message("Downloading addon %s: %.2f/%.2f MB (%.2f%%)\n", addon.c_str(), flMBDownloaded, flTotalMB, flProgress);
}

// bImportant adds downloads to the pending list, which will reload the current map once the list is exhausted
// bForce will initiate a download even if the addon already exists and is updated
// Internally, downloads are queued up and processed one at a time
bool MultiAddonManager::DownloadAddon(const char *pszAddon, bool bImportant, bool bForce)
{
	if (!GetSteamUGC())
	{
		Panic("%s: Cannot download addons as the Steam API is not initialized\n", __func__);
		return false;
	}

	const AddonId addon(pszAddon);
	PublishedFileId_t steamId = addon;

	if (steamId == 0)
	{
		Panic("%s: Invalid addon %s\n", __func__, pszAddon);
		return false;
	}

	if (Contains(m_DownloadQueue, addon))
	{
		Panic("%s: Addon %s is already queued for download!\n", __func__, pszAddon);
		return false;
	}

	uint32 nItemState = GetSteamUGC()->GetItemState(steamId);

	if (!bForce && (nItemState & k_EItemStateInstalled))
	{
		Message("Addon %s is already installed\n", pszAddon);
		return true;
	}

	if (!GetSteamUGC()->DownloadItem(steamId, false))
	{
		Panic("%s: Addon download for %s failed to start, addon ID is invalid or server is not logged on Steam\n", __func__, pszAddon);

		// Most likely the server hasn't logged on to Steam yet, retry once it does (see OnSteamServersConnected)
		AddonDownloadInfo_t pending = { addon, bImportant, bForce };

		if (!Contains(m_PreSteamLoginDownloads, pending))
			m_PreSteamLoginDownloads.push_back(pending);

		return false;
	}
	
	if (bImportant && !Contains(m_ImportantDownloads, addon))
		m_ImportantDownloads.push_back(addon);

	m_DownloadQueue.push_back(addon);

	Message("Addon download started for %s\n", pszAddon);

	return true;
}

void MultiAddonManager::OnSteamServersConnected(SteamServersConnected_t *pResult)
{
	Message("Logged on to Steam\n");

	m_bSteamConnected = true;

	if (m_PreSteamLoginDownloads.empty())
		return;

	// Downloads requested before the server logged on to Steam fail to start, so retry them now
	Message("Retrying %i pending addon download(s)\n", m_PreSteamLoginDownloads.size());

	for (const auto &download : m_PreSteamLoginDownloads)
		DownloadAddon(download.addon.c_str(), download.bImportant, download.bForce);

	m_PreSteamLoginDownloads.clear();
}

void MultiAddonManager::RefreshAddons(bool bReloadMap)
{
	if (!GetSteamUGC())
		return;

	Message("Refreshing addons (%s)\n", VectorToString(m_ExtraAddons).c_str());

	// Remove our paths first in case addons were switched
	for (const auto& addon : m_MountedAddons)
		UnmountAddon(addon);

	bool bAllAddonsMounted = true;

	for (const auto &addon : m_ExtraAddons)
	{
		if (!MountAddon(addon))
			bAllAddonsMounted = false;
	}

	if (bAllAddonsMounted && bReloadMap)
		ReloadMap();
}

void MultiAddonManager::ClearAddons()
{
	m_ExtraAddons.clear();

	// Update the convar to reflect the new addon list, but don't trigger the callback
	mm_extra_addons.GetConVarData()->Value(0)->m_StringValue = "";
	
	for (const auto& addon : m_MountedAddons)
		UnmountAddon(addon);
}

void MultiAddonManager::ReloadMap()
{
	char cmd[MAX_PATH];

	// Using the concommand here as g_pEngineServer->ChangeLevel doesn't unmount workshop maps and we wanna be clean.
	// See Hook_SetPendingHostStateRequest's comment for more details.
	// Community maps are treated like workshop maps but they should still be loaded using changelevel
	if (m_CurrentWorkshopMap.empty() || g_pFullFileSystem->IsDirectory(m_CurrentWorkshopMap.c_str(), "OFFICIAL_ADDONS"))
		V_snprintf(cmd, sizeof(cmd), "changelevel %s", GetGlobals()->mapname.ToCStr());
	else
		V_snprintf(cmd, sizeof(cmd), "host_workshop_map %s", m_CurrentWorkshopMap.c_str());

	g_pEngineServer->ServerCommand(cmd);
}

void MultiAddonManager::OnAddonDownloaded(DownloadItemResult_t *pResult)
{
	const AddonId addon(pResult->m_nPublishedFileId);

	if (pResult->m_eResult == k_EResultOK)
	{
		Message("Addon %s downloaded successfully\n", addon.c_str());
	}
	else
	{
		// Steam may add more errors
		static const int iNumMessages = ARRAYSIZE(g_SteamErrorMessages);
		const char *pszReason = pResult->m_eResult < iNumMessages ? g_SteamErrorMessages[pResult->m_eResult] : "Unknown error";

		Panic("Addon %s download failed with reason \"%s\" (%i)\n", addon.c_str(), pszReason, pResult->m_eResult);
	}

	RemoveValue(m_PreSteamLoginDownloads, addon);

	// This download isn't triggered by us, don't do anything
	if (!Contains(m_DownloadQueue, addon))
		return;

	RemoveValue(m_DownloadQueue, addon);
	
	bool bFound = RemoveValue(m_ImportantDownloads, addon);
	
	// That was the last important download, now reload the map
	if (bFound && m_ImportantDownloads.empty())
	{
		Message("All addon downloads finished, reloading map\n");
		ReloadMap();
	}
}

bool MultiAddonManager::AddAddon(const char *pszAddon, bool bRefresh)
{
	if (Contains(m_ExtraAddons, AddonId(pszAddon)))
	{
		Panic("Addon %s is already in the list!\n", pszAddon);
		return false;
	}

	Message("Adding %s to addon list\n", pszAddon);

	m_ExtraAddons.push_back(pszAddon);

	// Update the convar to reflect the new addon list, but don't trigger the callback
	mm_extra_addons.GetConVarData()->Value(0)->m_StringValue = VectorToString(m_ExtraAddons).c_str();

	Message("Clearing client cache due to addons changing\n");

	if (bRefresh)
		RefreshAddons();

	return true;
}

bool MultiAddonManager::RemoveAddon(const char *pszAddon, bool bRefresh)
{
	if (!Contains(m_ExtraAddons, AddonId(pszAddon)))
	{
		Panic("Addon %s is not in the list!\n", pszAddon);
		return false;
	}

	Message("Removing %s from addon list\n", pszAddon);

	RemoveValue(m_ExtraAddons, AddonId(pszAddon));

	// Update the convar to reflect the new addon list, but don't trigger the callback
	mm_extra_addons.GetConVarData()->Value(0)->m_StringValue = VectorToString(m_ExtraAddons).c_str();

	if (bRefresh)
		RefreshAddons();

	return true;
}

CNetMessagePB<CNETMsg_SignonState> *GetAddonSignonStateMessage(const char *pszAddon)
{
	if (!GetNetworkGameServer() || !GetGlobals())
		return nullptr;

	INetworkMessageInternal *pNetMsg = g_pNetworkMessages->FindNetworkMessagePartial("SignonState");
	CNetMessagePB<CNETMsg_SignonState> *pMsg = pNetMsg->AllocateMessage()->ToPB<CNETMsg_SignonState>();
	pMsg->set_spawn_count(GetGlobals()->serverCount);
	pMsg->set_signon_state(SIGNONSTATE_CHANGELEVEL);
	pMsg->set_addons(pszAddon ? pszAddon : "");
	auto& clientList = GetNetworkGameServer()->m_Clients;
	pMsg->set_num_server_players(clientList.Count());
	for (auto pClient : clientList)
	{
		char const *szNetworkId = g_pEngineServer->GetPlayerNetworkIDString(pClient->GetPlayerSlot());
		pMsg->add_players_networkids(szNetworkId);
	}

	return pMsg;
}

bool MultiAddonManager::HasUGCConnection()
{
	return GetSteamUGC() != nullptr && m_bSteamConnected;
}

void MultiAddonManager::AddClientAddon(const char *pszAddon, uint64 steamID64, bool bRefresh)
{
	if (!steamID64)
	{
		if (Contains(m_GlobalClientAddons, AddonId(pszAddon)))
		{
			Panic("Addon %s is already in the list!\n", pszAddon);
			return;
		}
	
		m_GlobalClientAddons.push_back(pszAddon);
		mm_client_extra_addons.GetConVarData()->Value(0)->m_StringValue = VectorToString(m_GlobalClientAddons).c_str();	
	}
	else
	{
		if (Contains(g_ClientAddons[steamID64].addonsToLoad, AddonId(pszAddon)))
		{
			Panic("Addon %s is already in the list!\n", pszAddon);
			return;
		}

		ClientAddonInfo_t &clientInfo = g_ClientAddons[steamID64];
		clientInfo.addonsToLoad.push_back(pszAddon);
	}
	
	if (bRefresh)
	{
		auto pMsg = GetAddonSignonStateMessage(pszAddon);
		if (!pMsg)
		{
			Panic("Failed to create signon state message for %s\n", pszAddon);
			return;
		}
		for (auto pClient : GetNetworkGameServer()->m_Clients)
		{
			uint64 clientSteamId = pClient->GetClientSteamID().ConvertToUint64();

			if (steamID64 != 0 && clientSteamId != steamID64)
				continue;

			// Client is already loading, telling them to reload now will actually just disconnect them. ("Received signon %i when at %i\n" in client console)
			if (pClient->GetSignonState() == SIGNONSTATE_CHANGELEVEL)
			{
				if (steamID64)
					break;

				continue;
			}
			// Client still has addons to load anyway, they don't need to be told to reload
			if (!g_ClientAddons[clientSteamId].currentPendingAddon.empty())
			{
				if (steamID64)
					break;

				continue;
			}
			ClientAddonInfo_t &clientInfo = g_ClientAddons[clientSteamId];

			std::vector<AddonId> addons;
			GetClientAddons(addons, clientSteamId);

			for (const auto &downloaded : clientInfo.downloadedAddons)
				RemoveValue(addons, downloaded);

			if (addons.empty())
			{
				if (steamID64)
					break;

				continue;
			}

			clientInfo.currentPendingAddon = addons.front();

			pClient->GetNetChannel()->SendNetMessage(pMsg, BUF_RELIABLE);

			if (steamID64)
				break;
		}
		delete pMsg;
	}
}

void MultiAddonManager::RemoveClientAddon(const char *pszAddon, uint64 steamID64)
{
	if (!steamID64)
	{
		RemoveValue(m_GlobalClientAddons, AddonId(pszAddon));
		mm_client_extra_addons.GetConVarData()->Value(0)->m_StringValue = VectorToString(m_GlobalClientAddons).c_str();	
	}
	else
	{
		ClientAddonInfo_t &clientInfo = g_ClientAddons[steamID64];
		RemoveValue(clientInfo.addonsToLoad, AddonId(pszAddon));
	}
}

void MultiAddonManager::ClearClientAddons(uint64 steamID64)
{
	if (!steamID64)
	{
		m_GlobalClientAddons.clear();
		mm_client_extra_addons.GetConVarData()->Value(0)->m_StringValue = VectorToString(m_GlobalClientAddons).c_str();	
	}
	else
	{
		ClientAddonInfo_t &clientInfo = g_ClientAddons[steamID64];
		clientInfo.addonsToLoad.clear();
	}
}

void MultiAddonManager::GetClientAddons(std::vector<AddonId> &addons, uint64 steamID64)
{
	addons.clear();
	
	if (!m_CurrentWorkshopMap.empty())
		addons.push_back(m_CurrentWorkshopMap);
	// The list of mounted addons should never contain the workshop map.
	addons.insert(addons.end(), m_MountedAddons.begin(), m_MountedAddons.end());
	// Also make sure we don't have duplicates.
	for (const auto &addon : m_GlobalClientAddons)
	{
		if (!Contains(addons, addon))
			addons.push_back(addon);
	}
	// If we specify a client steamID64, check for the addons exclusive to this client as well.
	if (steamID64)
	{
		for (const auto &addon : g_ClientAddons[steamID64].addonsToLoad)
		{
			if (!Contains(addons, addon))
				addons.push_back(addon);
		}
	}
}

CON_COMMAND_F(mm_add_client_addon, "Add a workshop ID to the global client-only addon list", FCVAR_SPONLY)
{
	if (args.ArgC() < 2)
	{
		Message("Usage: %s <ID>\n", args[0]);
		return;
	}
	g_MultiAddonManager.AddClientAddon(args[1]);
}

CON_COMMAND_F(mm_remove_client_addon, "Remove a workshop ID from the global client-only addon list", FCVAR_SPONLY)
{
	if (args.ArgC() < 2)
	{
		Message("Usage: %s <ID>\n", args[0]);
		return;
	}
	g_MultiAddonManager.RemoveClientAddon(args[1]);
}

CON_COMMAND_F(mm_add_addon, "Add a workshop ID to the extra addon list", FCVAR_SPONLY)
{
	if (args.ArgC() < 2)
	{
		Message("Usage: %s <ID>\n", args[0]);
		return;
	}

	g_MultiAddonManager.AddAddon(args[1]);
}

CON_COMMAND_F(mm_remove_addon, "Remove a workshop ID from the extra addon list", FCVAR_SPONLY)
{
	if (args.ArgC() < 2)
	{
		Message("Usage: %s <ID>\n", args[0]);
		return;
	}

	g_MultiAddonManager.RemoveAddon(args[1]);
}

CON_COMMAND_F(mm_download_addon, "Download an addon manually", FCVAR_SPONLY)
{
	if (args.ArgC() != 2)
	{
		Message("Usage: %s <ID>\n", args[0]);
		return;
	}

	g_MultiAddonManager.DownloadAddon(args[1], false, true);
}

CON_COMMAND_F(mm_print_searchpaths, "Print search paths", FCVAR_SPONLY)
{
	g_pFullFileSystem->PrintSearchPaths();
}

CON_COMMAND_F(mm_print_searchpaths_client, "Print search paths client-side, only usable if you're running the plugin on a listenserver", FCVAR_CLIENTDLL)
{
	g_pFullFileSystem->PrintSearchPaths();
}

KHook::Return<void> MultiAddonManager::Hook_StartupServer_Post(INetworkServerService *pThis, const GameSessionConfiguration_t &config, ISource2WorldSession *session, const char *mapname)
{
	m_TimedOutClients.clear();

	// Remove empty paths added when there are 2+ addons, they screw up file writes
	g_pFullFileSystem->RemoveSearchPath("", "GAME");
	g_pFullFileSystem->RemoveSearchPath("", "DEFAULT_WRITE_PATH");

	// This has to be done here to replicate the behavior on clients, where they mount addons in the string order
	// So if the current map is ID 1 and extra addons are IDs 2 and 3, they would be mounted in that order with ID 3 at the top
	// Note that the actual map VPK(s) and any sub-maps like team_select will be even higher, but those usually don't contain any assets that concern us
	RefreshAddons();

	return {KHook::Action::Ignore};
}

KHook::Return<bool> MultiAddonManager::Hook_SendNetMessage(CServerSideClientBase *pClient, const CNetMessage *pData, NetChannelBufType_t bufType)
{
	NetMessageInfo_t* info = pData->GetNetMessage()->GetNetMessageInfo();

	uint64 steamID64 = pClient->GetClientSteamID().ConvertToUint64();
	ClientAddonInfo_t& clientInfo = g_ClientAddons[steamID64];

	// If we are sending a message to the client, that means the client is still active.
	clientInfo.lastActiveTime = Plat_FloatTime();

	if (info->m_MessageId != net_SignonState || !g_pEngineServer->IsDedicatedServer())
		return {KHook::Action::Ignore};

	auto pMsg = const_cast<CNetMessage*>(pData)->ToPB<CNETMsg_SignonState>();

	std::vector<AddonId> addons;
	g_MultiAddonManager.GetClientAddons(addons, steamID64);

	if (pMsg->signon_state() == SIGNONSTATE_CHANGELEVEL)
	{
		// When switching to another map, the signon message might contain more than 1 addon.
		// This puts the client in limbo because client doesn't know how to handle multiple addons at the same time.
		std::vector<AddonId> addonsList;
		StringToVector(pMsg->addons().c_str(), addonsList);
		if (addonsList.size() > 1)
		{
			// If there's more than one addon, ensure that it takes the first addon (which should be the workshop map or the first custom addon)
			pMsg->set_addons(addonsList.front().c_str());
			// Since the client will download the addon contained inside this messsage, we might as well add it to the list of client's downloaded addons.
			clientInfo.currentPendingAddon = addonsList.front();
		}
		else if (addonsList.size() == 1)
		{
			// Nothing to do here, the rest of the required addons can be sent later.
			clientInfo.currentPendingAddon = pMsg->addons();
		}

		return {KHook::Action::Ignore};
	}
	for (const auto &downloaded : clientInfo.downloadedAddons)
		RemoveValue(addons, downloaded);

	// Check if client has downloaded everything.
	if (addons.empty())
		return { KHook::Action::Ignore };

	if (mm_addon_debug.Get())
		Message("%s: Number of addons remaining to download for %lli: %d\n", __func__, steamID64, (int)addons.size());

	// Otherwise, send the next addon to the client.
	clientInfo.currentPendingAddon = addons.front();
	pMsg->set_addons(addons.front().c_str());
	pMsg->set_signon_state(SIGNONSTATE_CHANGELEVEL);

	return {KHook::Action::Ignore};
}

// pMgrDoNotUse is named as such because the variable is optimized out in Windows builds and will not be passed to the function.
// The original Windows function just uses the global singleton instead.
KHook::Return<void> MultiAddonManager::Hook_SetPendingHostStateRequest(CHostStateMgr* pMgrDoNotUse, CHostStateRequest *pRequest)
{
	// When IVEngineServer::ChangeLevel is called by the plugin or the server code,
	// (which happens at the end of a map), the server-defined addon does not change.
	// Also, host state requests coming from that function will always have "ChangeLevel" in its KV's name.
	// We can use this information to always be aware of what the original addon is.

	m_LoadingWorkshopMap = m_CurrentWorkshopMap;
	
	if (!pRequest->m_pKV)
	{
		// g_pEngineServer->IsMapValid takes into account mounted addons so we have to do this instead
		char szFileName[MAX_PATH];
		V_snprintf(szFileName, sizeof(szFileName), "maps/%s.vpk", pRequest->m_LevelName.Get());
		bool bValveMap = g_pFullFileSystem->FileExists(szFileName, "MOD");

		// Workshop map changes from end of match votes have null keyvalues
		// ...and when such votes lead to reloading the CURRENT map, m_Addons will also be null, in which case we want to keep the workshop map unchanged
		if (!pRequest->m_Addons.IsEmpty())
			m_LoadingWorkshopMap = pRequest->m_Addons.Get();
		else if (bValveMap) // Sadly this will include any workshop maps that share names with shipped Valve maps, but at this point there's no way to tell
			m_LoadingWorkshopMap.clear();
	}
	else if (V_stricmp(pRequest->m_pKV->GetName(), "ChangeLevel"))
	{
		if (!V_stricmp(pRequest->m_pKV->GetName(), "map_workshop"))
			m_LoadingWorkshopMap = pRequest->m_pKV->GetString("customgamemode", "");
		else
			m_LoadingWorkshopMap.clear();
	}

	// Valve changed the way community maps (like de_dogtown) are loaded
	// Now their content lives in addons and they're mounted internally somehow (m_Addons is already set to it by this point)
	// So check if the addon is indeed one of the community maps and keep it, otherwise clients would error out due to missing assets
	// Each map has its own folder under game/csgo_community_addons which is mounted as "OFFICIAL_ADDONS"
	if (!pRequest->m_Addons.IsEmpty() && g_pFullFileSystem->IsDirectory(pRequest->m_Addons.String(), "OFFICIAL_ADDONS"))
		m_LoadingWorkshopMap = pRequest->m_Addons.Get();

	if (m_ExtraAddons.empty())
		return {KHook::Action::Ignore};

	// Rebuild the addon list. We always start with the original addon.
	if (m_LoadingWorkshopMap.empty())
	{
		pRequest->m_Addons = VectorToString(m_ExtraAddons).c_str();
	}
	else
	{
		// Don't add the same addon twice. Hopefully no server owner is diabolical enough to do things like `map de_dust2 customgamemode=1234,5678`.
		std::vector<AddonId> newAddons = m_ExtraAddons;
		RemoveValue(newAddons, m_LoadingWorkshopMap);
		newAddons.insert(newAddons.begin(), m_LoadingWorkshopMap);
		pRequest->m_Addons = VectorToString(newAddons).c_str();
	}

	return {KHook::Action::Ignore};
}

KHook::Return<void> MultiAddonManager::Hook_SwitchToLoop(IEngineServiceMgr* pThis, const char* pszLoopModeName, KeyValues* pkvLoopOptions, uint32 nId, const char* pszAddonName, bool)
{
	if (!V_stricmp(pszLoopModeName, "levelload"))
		m_CurrentWorkshopMap = m_LoadingWorkshopMap;

	return {KHook::Action::Ignore};
}

void MultiAddonManager::CheckClientAddons(uint64 steamID64)
{
	ClientAddonInfo_t &clientInfo = g_ClientAddons[steamID64];
	clientInfo.connectedState = CLIENTCONN_JOINED;

	std::vector<AddonId> addons;
	GetClientAddons(addons, steamID64);
	// We don't have an extra addon set so do nothing here, also don't do anything if we're a listenserver
	if (addons.empty() || !g_pEngineServer->IsDedicatedServer())
		return;

	if (!clientInfo.currentPendingAddon.empty())
	{
		if (Plat_FloatTime() - clientInfo.lastActiveTime > mm_extra_addons_timeout.Get())
		{
			if (mm_addon_debug.Get())
				Message("%s: Client %lli has reconnected after the timeout or did not receive the addon message, will not add addon %s to the downloaded list\n",
					__func__, steamID64, clientInfo.currentPendingAddon.c_str());
		}
		else
		{
			if (mm_addon_debug.Get())
				Message("%s: Client %lli has connected within the interval with the pending addon %s, will send next addon in SendNetMessage hook\n",
					__func__, steamID64, clientInfo.currentPendingAddon.c_str());

			clientInfo.downloadedAddons.push_back(clientInfo.currentPendingAddon);
		}
		// Reset the current pending addon anyway, SendNetMessage tells us which addon to download next.
		clientInfo.currentPendingAddon.clear();
	}
	clientInfo.lastActiveTime = Plat_FloatTime();
	return;
}

KHook::Return<bool> MultiAddonManager::Hook_ClientConnect(IServerGameClients *pThis, CPlayerSlot slot, const char *pszName, uint64 steamID64, const char *pszNetworkID, bool unk1, CBufferString *pRejectReason )
{
	CheckClientAddons(steamID64);
	return {KHook::Action::Ignore};
}

KHook::Return<bool> MultiAddonManager::Hook_CanHLTVClientConnect(IServerGameClients *pThis, int index, const CSteamID &steamID, int *pRejectReason)
{
	CheckClientAddons(steamID.ConvertToUint64());
	return {KHook::Action::Ignore};
}

KHook::Return<void> MultiAddonManager::Hook_ClientDisconnect_Post(IServerGameClients *pThis, CPlayerSlot slot, ENetworkDisconnectionReason reason, const char *pszName, uint64 steamID64, const char *pszNetworkID )
{
	// Mark the disconnection time for caching purposes.
	g_ClientAddons[steamID64].lastActiveTime = Plat_FloatTime();
	g_ClientAddons[steamID64].connectedState = CLIENTCONN_NONE;

	return {KHook::Action::Ignore};
}

KHook::Return<void> MultiAddonManager::Hook_ClientActive_Post(IServerGameClients *pThis, CPlayerSlot slot, bool bLoadGame, const char * pszName, uint64 steamID64)
{
	// When the client reaches this stage, they should already have all the necessary addons downloaded, so we can safely remove the downloaded addons list here.
	if (!mm_cache_clients_with_addons.Get())
		g_ClientAddons[steamID64].downloadedAddons.clear();

	return {KHook::Action::Ignore};
}

KHook::Return<void> MultiAddonManager::Hook_GameFrame_Post(IServerGameDLL *pThis, bool simulating, bool bFirstTick, bool bLastTick)
{
	static double s_flTime = 0.0f;

	// Print download progress every second
	if (Plat_FloatTime() - s_flTime > 1.f)
	{
		s_flTime = Plat_FloatTime();
		PrintDownloadProgress();
	}

	if (!m_TimedOutClients.size())
		return {KHook::Action::Ignore};

	for (auto pClient : GetNetworkGameServer()->m_Clients)
	{
		uint64 steamID64 = pClient->GetClientSteamID().ConvertToUint64();

		if (m_TimedOutClients.erase(steamID64))
		{
			pClient->Disconnect(NETWORK_DISCONNECT_TIMEDOUT, "Required Workshop addon download was not accepted in time");
			g_ClientAddons[steamID64].connectedState = CLIENTCONN_NONE;
		}
	}

	return {KHook::Action::Ignore};
}

KHook::Return<bool> MultiAddonManager::Hook_FireEvent(IGameEventManager2 *pThis, IGameEvent *event, bool bDontBroadcast)
{
	if (!event)
		return {KHook::Action::Ignore};

	static int s_iDisconnectId = -1;

	if (s_iDisconnectId == -1 && !V_strcmp(event->GetName(), "player_disconnect"))
		s_iDisconnectId = event->GetID();

	// This will prevent "loop shutdown" messages in the chat when clients reconnect
	// As far as we're aware, there are no other cases where this reason is used
	if (mm_block_disconnect_messages.Get() && event->GetID() == s_iDisconnectId && event->GetInt("reason") == NETWORK_DISCONNECT_LOOPSHUTDOWN)
		return {KHook::Action::Supersede, false};

	return {KHook::Action::Ignore};
}

KHook::Return<void> MultiAddonManager::Hook_ReplyConnection(CNetworkGameServerBase *pThis, CServerSideClient *pClient)
{
	uint64 steamID64 = pClient->GetClientSteamID().ConvertToUint64();
	// Clear cache if necessary.
	ClientAddonInfo_t &clientInfo = g_ClientAddons[steamID64];
	if (mm_cache_clients_with_addons.Get() && mm_cache_clients_duration.Get() != 0 && Plat_FloatTime() - clientInfo.lastActiveTime > mm_cache_clients_duration.Get())
	{
		if (mm_addon_debug.Get())
			Message("%s: Client %lli has not connected for a while, clearing the cache\n", __func__, steamID64);

		clientInfo.currentPendingAddon.clear();
		clientInfo.downloadedAddons.clear();
	}
	clientInfo.lastActiveTime = Plat_FloatTime();

	// Server copies the CUtlString from CNetworkGameServer to this client.
	CUtlString originalAddons = pThis->m_szAddonName;

	// Figure out which addons the client should be loading.
	std::vector<AddonId> clientAddons;
	GetClientAddons(clientAddons, steamID64);
	if (clientAddons.empty())
	{
		// No addons to send. This means the list of original addons is empty as well.
		assert(originalAddons.IsEmpty());
		clientInfo.currentPendingAddon.clear();
		return {KHook::Action::Ignore};
	}

	if (clientInfo.connectedState != CLIENTCONN_CONNECTING)
	{
		clientInfo.connectionStartTime = Plat_FloatTime();
		clientInfo.connectedState = CLIENTCONN_CONNECTING;
	}
	else if (mm_addon_connection_timeout.Get() > 0 &&
		clientInfo.connectedState == CLIENTCONN_CONNECTING && 
		Plat_FloatTime() - clientInfo.connectionStartTime > mm_addon_connection_timeout.Get())
	{
		// Can't kick right now as this will crash on windows, so defer to the next frame
		AddTimedOutClient(steamID64);
		return {KHook::Action::Supersede};
	}

	// Handle the first addon here. The rest should be handled in the SendNetMessage hook.
	if (!Contains(clientInfo.downloadedAddons, clientAddons[0]))
		clientInfo.currentPendingAddon = clientAddons[0];

	// In some cases, clients can do a signature check on addons which fails and instantly disconnects them
	// As a mitigation, remove all undownloaded addons so the client never does the failing signature check
	clientAddons.erase(
		std::remove_if(clientAddons.begin(), clientAddons.end(),
			[&](const AddonId &id)
			{
				return !Contains(clientInfo.downloadedAddons, id)
					&& id != clientInfo.currentPendingAddon;
			}),
		clientAddons.end());
	
	pThis->m_szAddonName = VectorToString(clientAddons).c_str();

	if (mm_addon_debug.Get())
		Message("%s: Sending addons %s to steamID64 %lli\n", __func__, pThis->m_szAddonName.Get(), steamID64);

	m_hookReplyConnection.CallOriginal(pThis, pClient);

	pThis->m_szAddonName = originalAddons;

	return {KHook::Action::Supersede};
}

KHook::Return<uint64> MultiAddonManager::Hook_ScriptGetAddon()
{
	if (m_ExtraAddons.empty() || m_CurrentWorkshopMap.empty())
		return {KHook::Action::Ignore};

	return {KHook::Action::Supersede, m_CurrentWorkshopMap};
}

using System.Globalization;
using System.Text.Json;
using System.Text.RegularExpressions;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Core.Translations;
using Microsoft.Extensions.Logging;

namespace MenuManagerCore;

// Menu labels such as SA_SLAP are replaced from
// configs/plugins/MenuManagerCore/MenuManager_Modules_Translation.json.
// The file is grouped by plugin, then by language. The menu only receives the
// finished string, so the plugin name is there for the person editing the file.
internal static class ModuleTranslations
{
    private const string FileName = "MenuManager_Modules_Translation.json";

    private const string Example = """
        {
          "CS2-SimpleAdmin": {
            "ru": {
              "SA_TITLE": "SimpleAdmin",
              "SA_MENU_PLAYERS_MANAGE": "Управление игроками",
              "SA_MENU_SERVER_MANAGE": "Управление сервером",
              "SA_MENU_ADMINS_MANAGE": "Управление администраторами",
              "SA_SLAP": "Шлепнуть",
              "SA_SLAY": "Убить",
              "SA_KICK": "Выгнать",
              "SA_WARN": "Предупреждение",
              "SA_BAN": "Забанить",
              "SA_GAG": "Заглушить",
              "SA_MUTE": "Отключить звук",
              "SA_SILENCE": "Тишина",
              "SA_TEAM_FORCE": "Принудить к команде",
              "SA_TEAM_CT": "CT",
              "SA_TEAM_T": "T",
              "SA_TEAM_SWAP": "Поменять",
              "SA_TEAM_SPEC": "Спец",
              "SA_HISTORY": "История",
              "SA_CHANGEMAP": "Сменить карту",
              "SA_RESTART_GAME": "Перезапустить игру",
              "SA_MENU_CUSTOM_COMMANDS": "Пользовательские команды",
              "SA_MENU_PLUGINSMANAGER_TITLE": "Управление плагинами",
              "SA_ADMIN_ADD": "Добавить администратора",
              "SA_ADMIN_REMOVE": "Удалить администратора",
              "SA_ADMIN_RELOAD": "Перезагрузить администраторов"
            },
            "en": {
              "SA_TITLE": "SimpleAdmin",
              "SA_MENU_PLAYERS_MANAGE": "Players Manage",
              "SA_MENU_SERVER_MANAGE": "Server Manage",
              "SA_MENU_ADMINS_MANAGE": "Admins Manage",
              "SA_SLAP": "Slap",
              "SA_SLAY": "Slay",
              "SA_KICK": "Kick",
              "SA_WARN": "Warn",
              "SA_BAN": "Ban",
              "SA_GAG": "Gag",
              "SA_MUTE": "Mute",
              "SA_SILENCE": "Silence",
              "SA_TEAM_FORCE": "Force Team",
              "SA_TEAM_CT": "CT",
              "SA_TEAM_T": "T",
              "SA_TEAM_SWAP": "Swap",
              "SA_TEAM_SPEC": "Spec",
              "SA_HISTORY": "History",
              "SA_CHANGEMAP": "Change Map",
              "SA_RESTART_GAME": "Restart Game",
              "SA_MENU_CUSTOM_COMMANDS": "Custom Commands",
              "SA_MENU_PLUGINSMANAGER_TITLE": "Plugins Manage",
              "SA_ADMIN_ADD": "Add Admin",
              "SA_ADMIN_REMOVE": "Remove Admin",
              "SA_ADMIN_RELOAD": "Reload Admins"
            }
          },
          "IksAdmin": {
            "ru": {
              "MenuTitle.AdminMain": "Админ меню",
              "MenuTitle.HELP_SelectItem": "Выберите:",
              "MenuTitle.Other.SelectReason": "Выберите причину",
              "MenuTitle.Other.SelectTime": "Выберите время",
              "MenuTitle.Other.SelectPlayer": "Выберите игрока",
              "MenuOption.Other.OwnReason": "Своя причина",
              "MenuOption.Other.OwnTime": "Своё время",
              "MenuOption.Other.Back": "← Назад",
              "MenuTitle.AM": "Управление админами",
              "MenuTitle.AM.Edit": "Редактирование админа",
              "MenuOption.AM": "Управление админами",
              "MenuOption.AM.Add": "Добавить админа",
              "MenuTitle.AM.Add": "Добавление админа",
              "MenuOption.AM.Delete": "Удалить админа",
              "MenuOption.AM.Edit": "Редактировать админа",
              "MenuTitle.AM.Edit_ServerId": "Выберите сервер",
              "MenuOption.AM.Save": "Сохранить админа",
              "MenuOption.AM.Edit.ThisServer": "Редактировать (этот сервер)",
              "MenuOption.AM.Edit.All": "Редактировать (все)",
              "MenuTitle.SM": "Управление сервером",
              "MenuOption.SM": "Управление сервером",
              "MenuOption.SM.Rcon": "Отправить RCON",
              "MenuOption.SM.ReloadData": "Обновить данные",
              "MenuTitle.GM": "Управление группами",
              "MenuTitle.GM.Add": "Управление группами",
              "MenuTitle.GM.Editing": "Изменение группы",
              "MenuOption.GM": "Управление группами",
              "MenuOption.GM.Add": "Добавить группу",
              "MenuOption.GM.Delete": "Удалить группу",
              "MenuOption.GM.Edit": "Редактировать группу",
              "MenuOption.GM.Save": "Сохранить группу",
              "MenuTitle.CM": "Управление чатом",
              "MenuOption.CM": "Управление чатом",
              "MenuOption.CM.Add": "Добавить блокировку",
              "MenuTitle.CM.UnComm": "Удалить блокировку чата",
              "MenuTitle.CM.SelectType": "Выберите тип блокировки",
              "MenuOption.CM.Mute": "Мут",
              "MenuOption.CM.Gag": "Гаг",
              "MenuOption.CM.Silence": "Всё",
              "MenuOption.CM.Remove": "Удалить блокировку",
              "MenuOption.CM.RemoveOffline": "Удалить блокировку (оффлайн)",
              "MenuTitle.PM.Main": "Управление игроками",
              "MenuOption.PM": "Управление игроками",
              "MenuOption.PM.Kick": "Кикнуть",
              "MenuOption.PM.Slay": "Убить",
              "MenuOption.PM.Respawn": "Возродить",
              "MenuOption.PM.Team": "Сменить команду",
              "MenuOption.PM.Rename": "Переименовать игрока",
              "MenuTitle.PM.SelectTeam": "Выберите команду:",
              "MenuTitle.PM.SelectTeamMode": "Выберите:",
              "MenuTitle.PM.SelectChangeTeamTime": "Выберите когда:",
              "MenuOption.PM.Now": "Сейчас",
              "MenuOption.PM.OnRoundEnd": "В конце раунда",
              "MenuOption.PM.ChangeTeam": "С убийством",
              "MenuOption.PM.SwitchTeam": "Без убийства",
              "MenuTitle.BM": "Управление блокировками",
              "MenuOption.BM": "Управление блокировками",
              "MenuTitle.BansManage": "Управление банами",
              "MenuOption.BansManage": "Управление банами",
              "MenuTitle.AddBan": "Добавить бан",
              "MenuOption.AddBan": "Добавить бан",
              "MenuTitle.BanType": "Выберите тип бана",
              "MenuOption.BanSteamId": "Steam ID",
              "MenuOption.BanIp": "IP",
              "MenuTitle.AddOfflineBan": "Добавить бан (offline)",
              "MenuOption.AddOfflineBan": "Добавить бан (offline)",
              "MenuTitle.Unban": "Снять бан",
              "MenuOption.Unban": "Снять бан",
              "MenuTitle.Warns.Main": "Управление варнами",
              "MenuOption.Warns": "Управление варнами",
              "MenuOption.Warns.Add": "Выдать варн",
              "MenuOption.Warns.List": "Список варнов",
              "MenuTitle.Warns.List": "Список варнов"
            },
            "en": {
              "MenuTitle.AdminMain": "Admin Menu",
              "MenuTitle.HELP_SelectItem": "Select:",
              "MenuTitle.Other.SelectReason": "Select Reason",
              "MenuTitle.Other.SelectTime": "Select Time",
              "MenuTitle.Other.SelectPlayer": "Select Player",
              "MenuOption.Other.OwnReason": "Own Reason",
              "MenuOption.Other.OwnTime": "Own Time",
              "MenuOption.Other.Back": "← Back",
              "MenuTitle.AM": "Admin Management",
              "MenuTitle.AM.Edit": "Edit Admin",
              "MenuOption.AM": "Admin Management",
              "MenuOption.AM.Add": "Add Admin",
              "MenuTitle.AM.Add": "Add Admin",
              "MenuOption.AM.Delete": "Delete Admin",
              "MenuOption.AM.Edit": "Edit Admin",
              "MenuTitle.AM.Edit_ServerId": "Select Server",
              "MenuOption.AM.Save": "Save Admin",
              "MenuOption.AM.Edit.ThisServer": "Edit (this server)",
              "MenuOption.AM.Edit.All": "Edit (all)",
              "MenuTitle.SM": "Server Management",
              "MenuOption.SM": "Server Management",
              "MenuOption.SM.Rcon": "Send RCON",
              "MenuOption.SM.ReloadData": "Reload Data",
              "MenuTitle.GM": "Group Management",
              "MenuTitle.GM.Add": "Group Management",
              "MenuTitle.GM.Editing": "Editing Group",
              "MenuOption.GM": "Group Management",
              "MenuOption.GM.Add": "Add Group",
              "MenuOption.GM.Delete": "Delete Group",
              "MenuOption.GM.Edit": "Edit Group",
              "MenuOption.GM.Save": "Save Group",
              "MenuTitle.CM": "Chat Management",
              "MenuOption.CM": "Chat Management",
              "MenuOption.CM.Add": "Add Block",
              "MenuTitle.CM.UnComm": "Remove Chat Block",
              "MenuTitle.CM.SelectType": "Select Block Type",
              "MenuOption.CM.Mute": "Mute",
              "MenuOption.CM.Gag": "Gag",
              "MenuOption.CM.Silence": "Silence",
              "MenuOption.CM.Remove": "Remove Block",
              "MenuOption.CM.RemoveOffline": "Remove Block (offline)",
              "MenuTitle.PM.Main": "Player Management",
              "MenuOption.PM": "Player Management",
              "MenuOption.PM.Kick": "Kick",
              "MenuOption.PM.Slay": "Slay",
              "MenuOption.PM.Respawn": "Respawn",
              "MenuOption.PM.Team": "Change Team",
              "MenuOption.PM.Rename": "Rename player",
              "MenuTitle.PM.SelectTeam": "Select Team:",
              "MenuTitle.PM.SelectTeamMode": "Select:",
              "MenuTitle.PM.SelectChangeTeamTime": "Select When:",
              "MenuOption.PM.Now": "Now",
              "MenuOption.PM.OnRoundEnd": "At Round End",
              "MenuOption.PM.ChangeTeam": "With Kill",
              "MenuOption.PM.SwitchTeam": "Without Kill",
              "MenuTitle.BM": "Block Management",
              "MenuOption.BM": "Block Management",
              "MenuTitle.BansManage": "Ban Management",
              "MenuOption.BansManage": "Ban Management",
              "MenuTitle.AddBan": "Add Ban",
              "MenuOption.AddBan": "Add Ban",
              "MenuTitle.BanType": "Select Ban Type",
              "MenuOption.BanSteamId": "Steam ID",
              "MenuOption.BanIp": "IP",
              "MenuTitle.AddOfflineBan": "Add Ban (offline)",
              "MenuOption.AddOfflineBan": "Add Ban (offline)",
              "MenuTitle.Unban": "Unban",
              "MenuOption.Unban": "Unban",
              "MenuTitle.Warns.Main": "Warn Management",
              "MenuOption.Warns": "Warn Management",
              "MenuOption.Warns.Add": "Issue Warn",
              "MenuOption.Warns.List": "Warn List",
              "MenuTitle.Warns.List": "Warn List"
            }
          }
        }
        """;

    private static readonly Regex Token = new(
        @"(?<![A-Za-z0-9_.])([A-Za-z][A-Za-z0-9_.]*[_.][A-Za-z0-9_.]*)(?![A-Za-z0-9_.])",
        RegexOptions.Compiled | RegexOptions.CultureInvariant);

    private static readonly object Gate = new();
    private static Dictionary<string, Dictionary<string, string>> _byLanguage =
        new(StringComparer.OrdinalIgnoreCase);

    private static string _path = "";
    private static DateTime _writtenAt = DateTime.MinValue;
    private static ILogger? _logger;

    public static void Load(string moduleDirectory, ILogger logger)
    {
        _logger = logger;
        _path = Path.GetFullPath(Path.Combine(
            moduleDirectory, "..", "..", "configs", "plugins", "MenuManagerCore", FileName));
        Read(createIfMissing: true);
    }

    public static string Apply(CCSPlayerController player, string text)
    {
        if (string.IsNullOrEmpty(text) || !Token.IsMatch(text))
        {
            return text;
        }

        ReloadIfChanged();
        if (_byLanguage.Count == 0)
        {
            return text;
        }

        CultureInfo culture;
        try
        {
            culture = player.GetLanguage();
        }
        catch
        {
            culture = CultureInfo.InvariantCulture;
        }

        return Token.Replace(text, match => Lookup(match.Value, culture) ?? match.Value);
    }

    private static void ReloadIfChanged()
    {
        if (string.IsNullOrEmpty(_path) || !File.Exists(_path))
        {
            return;
        }

        DateTime written = File.GetLastWriteTimeUtc(_path);
        if (written != _writtenAt)
        {
            Read(createIfMissing: false);
        }
    }

    private static void Read(bool createIfMissing)
    {
        lock (Gate)
        {
            if (createIfMissing && !File.Exists(_path))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
                File.WriteAllText(_path, Example.Trim());
                _logger?.LogInformation("Module translations created: {Path}", _path);
            }

            Dictionary<string, Dictionary<string, string>> next =
                new(StringComparer.OrdinalIgnoreCase);
            if (!File.Exists(_path))
            {
                _byLanguage = next;
                return;
            }

            try
            {
                using JsonDocument doc = JsonDocument.Parse(File.ReadAllText(_path));
                if (doc.RootElement.ValueKind == JsonValueKind.Object)
                {
                    foreach (JsonProperty module in doc.RootElement.EnumerateObject())
                    {
                        if (module.Value.ValueKind != JsonValueKind.Object)
                        {
                            continue;
                        }

                        foreach (JsonProperty language in module.Value.EnumerateObject())
                        {
                            if (language.Value.ValueKind != JsonValueKind.Object)
                            {
                                continue;
                            }

                            if (!next.TryGetValue(language.Name, out Dictionary<string, string>? map))
                            {
                                map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                                next[language.Name] = map;
                            }

                            foreach (JsonProperty phrase in language.Value.EnumerateObject())
                            {
                                if (phrase.Value.ValueKind != JsonValueKind.String)
                                {
                                    continue;
                                }

                                string? value = phrase.Value.GetString();
                                if (string.IsNullOrEmpty(value))
                                {
                                    continue;
                                }

                                if (!map.TryAdd(phrase.Name, value))
                                {
                                    _logger?.LogWarning(
                                        "Module translations: {Key} is already set, skipped in {Module}",
                                        phrase.Name, module.Name);
                                }
                            }
                        }
                    }
                }

                _writtenAt = File.GetLastWriteTimeUtc(_path);
                _byLanguage = next;
                _logger?.LogInformation(
                    "Module translations: {Languages} languages from {Path}", next.Count, _path);
            }
            catch (Exception ex)
            {
                _logger?.LogWarning(ex, "Module translations: could not read {Path}", _path);
            }
        }
    }

    private static string? Lookup(string token, CultureInfo culture)
    {
        foreach (string name in Candidates(culture))
        {
            if (_byLanguage.TryGetValue(name, out Dictionary<string, string>? map) &&
                map.TryGetValue(token, out string? value))
            {
                return value;
            }
        }

        return null;
    }

    private static IEnumerable<string> Candidates(CultureInfo culture)
    {
        if (!string.IsNullOrEmpty(culture.Name))
        {
            yield return culture.Name;
        }

        if (!string.IsNullOrEmpty(culture.Parent.Name) &&
            !string.Equals(culture.Parent.Name, culture.Name, StringComparison.OrdinalIgnoreCase))
        {
            yield return culture.Parent.Name;
        }

        if (!string.IsNullOrEmpty(culture.TwoLetterISOLanguageName) &&
            !string.Equals(culture.TwoLetterISOLanguageName, culture.Name, StringComparison.OrdinalIgnoreCase))
        {
            yield return culture.TwoLetterISOLanguageName;
        }

        yield return "en";
    }
}
